<?php

namespace App\Http\Controllers\Admin;
use Route;
use Auth;
use App\Models\Permission;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ProductController extends Controller
{

    public function productList()
    {
    	$data['title'] = 'Product List';
    	return view('pages.product.list', $data);
    }

    public function limitedProduct()
    {
    	$data['title'] = 'Limited Product List';
    	return view('pages.product.limited_product_list', $data);
    }

    public function uplodaProductImage()
    {
        $data['title'] = 'Upload Product Image';
        return view('pages.product.upload_product_image', $data);
    }
}
