@extends('pages.layouts.app')

@section('content')

@endsection      
@section('script')

@endsection