<div class="row">
     <!-- my-modal-edit -->
<div wire:ignore.self class="modal fade" id="productEdit" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header modal-colored-header bg-primary">
                <h4 class="modal-title" id="myLargeModalLabel">Product Edit</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <form wire:submit.prevent="updateProduct">
            <input type="hidden" wire:model.defer="state.id" >
            <div class="modal-body">

                <div class="row mt-2 mb-2">

                    <div class="mb-3 col-md-6">
                        <label class="form-label">Product Title</label>
                        <input type="text" class="form-control" placeholder="Product Title" wire:model.defer="state.name">
                        @error('name') <span class="text-danger error">{{ $message }}</span>@enderror
                    </div>
                    @if(isset($state['product_code']))
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Product Code</label>
                        <input type="text" class="form-control" placeholder="Product Code" wire:model.defer="state.product_code">
                        @error('product_code') <span class="text-danger error">{{ $message }}</span>@enderror
                    </div>
                    @endif
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Quantity</label>
                        <input type="text" class="form-control" placeholder="Quantity" onkeypress="return number_check(event);" wire:model.defer="state.quantity">
                        @error('quantity') <span class="text-danger error">{{ $message }}</span>@enderror
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Quantity Alert</label>
                        <input type="text" class="form-control" placeholder="Quantity Alert" onkeypress="return number_check(event);" wire:model.defer="state.default_quantity">
                        @error('default_quantity') <span class="text-danger error">{{ $message }}</span>@enderror
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Purchase Price</label>
                        <input type="text" class="form-control" placeholder="Purchase Price" wire:model.defer="state.purchase_price">
                        @error('purchase_price') <span class="text-danger error">{{ $message }}</span>@enderror
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Selling Price</label>
                        <input type="text" class="form-control" placeholder="Selling Price" wire:model.defer="state.selling_price">
                        @error('selling_price') <span class="text-danger error">{{ $message }}</span>@enderror
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Product Image</label>
                        <input type="file" id="example-fileinput" class="form-control" wire:model.defer="state.image" accept="image/*">
                    </div>

                    @if(isset($state['gallery_image']))
                        <div class="mb-3 col-md-6">
                            <img src="{{asset('storage/app/public/product_image/'.$state['gallery_image']) }}" height="100px" >
                        </div>
                    @endif

                </div>          
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">Submit</button>
            </div>
            </form>
        </div>
    </div>
</div>

<!-- View Modal -->
<div wire:ignore.self id="productView" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header modal-colored-header bg-primary">
                <h4 class="modal-title" id="primary-header-modalLabel">Stock</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <div class="row ">
                    <div class="col-xl-12">
                        <div class="row gy-2 gx-2 align-items-center justify-content-xl-start justify-content-between">
                            <div class="col-auto">
                                <div class="mb-3">
                                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Back</button>                                                
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="table-responsive">
                    <table class="table table-bordered table-centered w-100 dt-responsive nowrap" id="products-datatable">
                        <thead class="table-light">
                            <tr>
                                <th>Date</th>
                                <th>Product Name</th>
                                <th>Quantity</th>
                                @if(Auth::user()->type=='A')
                                    <th>Purchase Price</th>
                                @endif
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($viewProduct->productQuantities) && count(@$viewProduct->productQuantities)>0)
                            @foreach(@$viewProduct->productQuantities as $productView)
                                <tr>
                                    <td>{{@$productView->date}}</td>
                                    <td>{{@$viewProduct->name}}</td>
                                    <td>{{@$productView->quantity}}</td>
                                    @if(Auth::user()->type=='A')
                                        <td>{{@$viewProduct->purchase_price}}</td>
                                    @endif
                                </tr>
                            @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
                @if(isset($viewProduct->productReductions) && count(@$viewProduct->productReductions)>0)
                <div class="table-responsive">
                    <table class="table table-bordered table-centered w-100 dt-responsive nowrap" id="products-datatable">
                        <thead class="table-light">
                            <tr>
                                <th colspan="3" style="background-color: #009CEC;">Stock Reduction</th>
                            </tr>
                            <tr>
                                <th>Date</th>
                                <th>Product Name</th>
                                <th>Quantity</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            @foreach(@$viewProduct->productReductions as $productView)
                                <tr>
                                    <td>{{@$productView->date}}</td>
                                    <td>{{@$productView->pro_name}}</td>
                                    <td>{{@$productView->qty}}</td>
                                </tr>
                            @endforeach
                            
                        </tbody>
                    </table>
                </div>
                @endif
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<!-- /.modal -->


    <div class="col-12">
        <div class="card">
            <div class="card-body">
                @if(Auth::user()->type=='A' || in_array('product-add', Auth::user()->permissions()->pluck('permission')->toArray()))
                <form wire:submit.prevent="save">
                <div class="row">
                    <div class="mb-3 col-md-6" style="position: relative;">
                        <label class="form-label">Product Title</label>
                        <input type="text" class="form-control" placeholder="Product Title" wire:model="name">
                        <ul id="serch_result" class="product_search"  @if(count($productSearch) == '0') style="display: none" @endif>
                            @if(count($productSearch)>0)
                            @foreach($productSearch as $value)
                            <li wire:click="getProductDetails({{$value->id}})"><a href="javascript:void(0)">{{$value->name}}</a></li>
                            @endforeach
                            @endif
                        </ul>
                        @error('name') <span class="text-danger error">{{ $message }}</span>@enderror
                    </div>

                    <input type="hidden" wire:model.defer="product_id">

                    @if(isset($product_code))
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Product Code</label>
                        <input type="text" class="form-control" placeholder="Product Code" wire:model.defer="product_code" maxlength="6">
                        @error('product_code') <span class="text-danger error">{{ $message }}</span>@enderror
                    </div>
                    @endif

                    <div class="mb-3 col-md-6">
                        <label class="form-label">Quantity</label>
                        <input type="text" class="form-control" placeholder="Quantity" onkeypress="return number_check(event);" wire:model.defer="quantity">
                        @error('quantity') <span class="text-danger error">{{ $message }}</span>@enderror
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Quantity Alert</label>
                        <input type="text" onkeypress="return number_check(event);" class="form-control" placeholder="Quantity Alert" wire:model.defer="default_quantity">
                        @error('default_quantity') <span class="text-danger error">{{ $message }}</span>@enderror
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Purchase Price</label>
                        <input type="text" class="form-control" placeholder="Purchase Price" wire:model.defer="purchase_price" @if(isset($product_id)) readonly="" @endif>
                        @error('purchase_price') <span class="text-danger error">{{ $message }}</span>@enderror
                    </div>
                    <div class="mb-3 col-md-6">
                        <label class="form-label">Selling Price</label>
                        <input type="text" class="form-control" placeholder="Selling Price" wire:model.defer="selling_price"  @if(isset($product_id)) readonly="" @endif>
                        @error('selling_price') <span class="text-danger error">{{ $message }}</span>@enderror
                    </div>
                    <div class="mb-3 col-md-6">
                        <div class="mb-3">
                            <label for="example-fileinput" class="form-label">Product Image</label>
                            <input type="file" id="example-fileinput" class="form-control" wire:model.defer="image" accept="image/*">
                            @error('image') <span class="text-danger error">{{ $message }}</span>@enderror
                        </div>                                           
                    </div>
                    @if(isset($gallery_image))
                    <div class="mb-3 col-md-6">
                        <img src="{{asset('storage/app/public/product_image/'.$gallery_image) }}" alt="contact-img" title="contact-img"  height="70" />
                    </div>
                    @endif

                </div>

                <div class="mb-3 text-center">
                    <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">Submit</button>
                </div>
                </form>
                @endif

                <div class="row mb-2">
                    <div class="col-xl-8">
                        @if(Auth::user()->type=='A')
                        <form class="row gy-2 gx-2 align-items-center justify-content-xl-start justify-content-between">
                            <div class="col-auto">
                                <div class="d-flex align-items-center">
                                    <!-- <label for="status-select" class="me-2">Status</label> -->
                                    <select class="form-select" wire:model="storeUser">
                                        <option value="" disabled="">Select Store</option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                    </select>
                                </div>
                            </div>
                        </form>                            
                        @endif
                    </div>
                    
                    <div class="col-xl-4">
                        <div class="row gy-2 gx-2 align-items-center justify-content-xl-end">
                            <div class="col-auto">
                                <label for="inputPassword2" class="visually-hidden">Search</label>
                                <input type="search" class="form-control" id="inputPassword2" wire:model="searchName" placeholder="Search...">
                            </div>                                                
                        </div>
                    </div>
                    <!-- <div class="col-xl-2">
                        <div class="row gy-2 gx-2 align-items-center justify-content-xl-end">
                            <a href="javascript:void(0)" onclick="PrintBarcode()" class="btn btn-primary">Print Barcode</a>                                               
                        </div>
                    </div> -->
                    <!-- end col-->
                    <div wire:loading wire:target="storeUser">
                        <div class="loader_sectin" id="loader_section" >
                            <div class="loader_overlay"></div>
                            <div id="loader" class="center" ></div>
                        </div>                
                    </div>
                    <div wire:loading wire:target="resetSearch">
                        <div class="loader_sectin" id="loader_section" >
                            <div class="loader_overlay"></div>
                            <div id="loader" class="center" ></div>
                        </div> 
                    </div>
                    <div wire:loading wire:target="loadMore">
                        <div class="loader_sectin" id="loader_section" >
                            <div class="loader_overlay"></div>
                            <div id="loader" class="center" ></div>
                        </div> 
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered table-centered w-100 dt-responsive nowrap"
                        id="products-datatable">
                        <thead class="table-light">
                            <tr>
                                <th>SL No.</th>
                                <th>Image</th>
                                <th>Products Name</th>
                                <th>Code</th>
                                <th>Product Qty</th>
                                <th>Qty</th>
                                <th>Selling Price</th>
                                <th>Discount</th>        
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        	@if(count($products)>0)
                        	@foreach($products as $key=>$row)
                            <tr>
                                <td>{{$key+1}}</td>
                                <td>
                                	@if(isset($row->gallery))
                                    <a data-fancybox="gallery" href="{{asset('storage/app/public/product_image/'.$row->gallery->gallery_image) }}">
                                        <img src="{{asset('storage/app/public/product_image/'.$row->gallery->gallery_image) }}" alt="contact-img"
                                            title="contact-img" class="rounded me-3" height="48" />
                                    </a>
                                    @else
                                    <img src="{{asset('public/assets/images/no_image.png') }}" alt="contact-img"
                                            title="contact-img" class="rounded me-3" height="48" />
                                    @endif
                                </td>
                                @php
                                    $avl_qty = 0;
                                    $avl_qty = $row->product_quantities_sum_quantity-($row->return_products_quantity_sum_qty+$row->product_orders_sum_qty+$row->productReductions->sum('qty'));

                                @endphp
                                <td>{{$row->name}}</td>
                                <td>{{$row->product_code}}</td>
                                <td>{{$avl_qty}}</td>
                                
                                <td>
                                    <div class="plusminus">
                                        <button class="btn btn-primary" type="button" wire:click="decrementQuantity({{$row->id}},{{$key}})" style="margin: 0;">-</button>
                                        <input  type="text" wire:model="cart_quantity.{{$key}}" >                <button class="btn btn-primary" type="button" wire:click="incrementQuantity({{$row->id}},{{$key}})" style="margin: 0;">+</button>
                                    </div>
                                </td>
                                <td>{{$row->selling_price}}</td>
                                <td><input  type="text" wire:model="discount.{{$key}}"> </td>
                                <td>
                                    @if(Auth::user()->type=='A' || in_array('add-to-cart', Auth::user()->permissions()->pluck('permission')->toArray()))
                                    <a href="javascript:void(0);" class="action-icon" wire:click="addToCart({{$row->id}}, {{$key}})" title="Add To Cart"><i class="mdi mdi-shopping-outline"></i></a>
                                    @endif
                                    @if(Auth::user()->type=='A' || in_array('product-view', Auth::user()->permissions()->pluck('permission')->toArray()))
                                    <a href="javascript:void(0);" class="action-icon" wire:click="viewProduct({{$row->id}})" title="View"><i class="mdi mdi-eye"></i></a>
                                    @endif
                                    @if(Auth::user()->type=='A' || in_array('product-edit', Auth::user()->permissions()->pluck('permission')->toArray()))
                                    <a href="javascript:void(0);" class="action-icon" wire:click="editProduct({{$row->id}})" title="Edit"><i class="mdi mdi-square-edit-outline"></i></a>
                                    @endif
                                    @if(Auth::user()->type=='A' || in_array('product-delete', Auth::user()->permissions()->pluck('permission')->toArray()))
                                    <a href="javascript:void(0);" class="action-icon" id="warning" wire:click="deleteAttempt({{ $row->id }})" title="Delete"><i class="mdi mdi-delete"></i></a>
                                    @endif
                                </td>
                            </tr>
                            @endforeach
                            @else
                            <tr>
                            	<td colspan="9" class="align-center">No records available</td>
                            </tr>
                            @endif
                        </tbody>
                    </table>
                </div>
                @if($products->hasMorePages())
                    <button wire:click.prevent="loadMore" class="btn btn-primary">Load more</button>
                @endif
            </div> <!-- end card-body -->
        </div> <!-- end card -->
    </div><!-- end col -->

    <!-- <div class="col-12" id="print_data" style="display: none;">
        <div class="card">
            <div class="card-body">
                <div class="row mb-2">
                    <div class="col-xl-12">
                        <div class="barcode_table" style="width: 100%">

                            
                            @if(count($printProducts)>0)
                            @foreach($printProducts as $printProduct)
                                <div class="pro" style="width: 200px;border: 1px dashed #000;text-align: center;padding: 5px 15px;float: left; height: 100px">

                                    <img style="width: 100%; height: 50px;" src="data:image/png;base64,{{DNS1D::getBarcodePNG($printProduct->product_code, 'C39')}}" alt="barcode" />
                                    <p style="padding: 0px 36px; margin-top: 5px; font-size: 15px;">{{$printProduct->name}}</p>                   
                                </div>
                            @endforeach
                            @endif
                                               
                                                
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->

   <a href="{{route('add_to_cart')}}" class="btn btn-primary btn-lg cart-btn " role="button" title="" data-toggle="tooltip" data-original-title="cart">
      <i class="uil-shopping-cart-alt" id="cart">@if(isset($count_cart_item)) {{$count_cart_item}} @endif</i>
  </a>
    
<script type="text/javascript">
    function PrintBarcode() {
    var divToPrint = document.getElementById('print_data');
    var popupWin = window.open('', '_blank', 'width=900,height=650');
    popupWin.document.open();
    popupWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
    popupWin.document.close();

}
</script>

</div>
