<?php

namespace App\Http\Controllers\Api;

use App\Models\User;
use App\Models\LoginDetails;
use Illuminate\Support\Facades\Auth;
use Validator;
use DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "email" =>  "required|exists:users",
            "password" =>  "required",
            "latitute" =>  "required|numeric",
            "longitute" =>  "required|numeric",
        ]);

        if($validator->fails()) {
            return response()->json(["validation_errors" => $validator->errors()]);
        }

        if($request->latitute && $request->longitute)
        {
            
            $today = date('Y-m-d');
        	if(Auth::attempt(['email' => $request->email, 'password' => $request->password]))
            { 
                $user = Auth::user(); 
                if($user->status == '0')
                {
                    return response()->json([
                        'success'=>false ,
                        'message'=>'Account not active.Please contact to admin',
                    ]);
                }
                if($user->latitute && $user->longitute)
                {
                    $latitute = $request->latitute;
                    $longitute = $request->longitute;
                    $data = User::where('id', $user->id)->select('id','name','address', 'latitute', 'longitute', DB::raw("6371 * acos(cos(radians(" . $latitute . ")) 
                    * cos(radians(latitute)) 
                    * cos(radians(longitute) - radians(" . $longitute . ")) 
                    + sin(radians(" .$latitute. ")) 
                    * sin(radians(latitute))) AS distance"))->having('distance','<', env('SET_DISTANCE',0.100))->first();

                    if(is_null($data))
                    {
                        return response()->json([
                            'success'=>false ,
                            'message'=>'Location not matched',
                        ]);
                    }

                    $is_logged_in = LoginDetails::where('user_id', $user->id)->where('date', $today)->first();
                    if($is_logged_in)
                    {
                        return response()->json([
                            'success'=>false ,
                            'message'=>'User Already logged In' ,
                        ]);
                    }
                    else{

                        $new_data = LoginDetails::create([
                            'user_id' => $user->id,
                            'date' => $today,
                            'login_time' => date('H:i:s'),
                            'latitute' => $request->latitute,
                            'longitute' => $request->longitute,
                        ]);

                        $user = User::with('today_login_details')->find(Auth::user()->id);
                        $success['token'] =  $user->createToken('sohan')->accessToken; 
                        $success['user'] =  $user;
               
                        return response()->json([
                            'success' => true,
                            'message' => 'Login Successfully',
                            'data' => $success
                        ]);
                    } 
                }
                else{
                    $user = User::with('today_login_details')->find(Auth::user()->id);
                    $success['token'] =  $user->createToken('sohan')->accessToken; 
                    $success['user'] =  $user;
           
                    return response()->json([
                        'success' => true,
                        'message' => 'Login Successfully. Please update your address',
                        'data' => $success
                    ]);
                }
                
            } 
            else{ 
                return response()->json([
                    'success'=>false ,
                    'message'=>'Email not found! Please try again' ,
                ]);
            }
        } 
        else{ 
            return response()->json([
	    		'success'=>false ,
	    		'message'=>'Please set your address' ,
	    	]);
        } 
    }

    public function logOut(Request $request)
    {
        $today = date('Y-m-d');
        $user = Auth::user(); 
        $is_logged_in = LoginDetails::where('user_id', $user->id)->where('date', $today)->first();
        if(is_null($is_logged_in))
        {
            return response()->json([
                'success'=>false ,
                'message'=>'Please Logged In' ,
            ]);
        }
        else{

            $is_logged_in->update([
                'logout_time' => date('H:i:s'),
            ]);

            /*$user = User::with('today_login_details')->find(Auth::user()->id);
            $success['user'] =  $user;*/
   
            return response()->json([
                'success' => true,
                'message' => 'Logout Successfully',
            ]);
        }
    }
}
