<?php

namespace App\Http\Livewire\Admin\Setting;

use Livewire\Component;

class AdminSetting extends Component
{
    public function render()
    {
        return view('livewire.admin.setting.admin-setting');
    }
}
